package cr.ac.ucr.planDeEstudios.datos;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import cr.ac.ucr.planDeEstudios.dominio.Carrera;

@Repository
public class CarreraDatos {
/*
	
	private static List<Carrera> carreras = new ArrayList<Carrera>();
	
	@Autowired
	public List<Carrera> encontrarCarrera(String nombre) {
		
		
		
		return null;
	}
*/
}
