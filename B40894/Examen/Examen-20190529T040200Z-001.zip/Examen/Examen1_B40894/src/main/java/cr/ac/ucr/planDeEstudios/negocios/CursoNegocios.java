package cr.ac.ucr.planDeEstudios.negocios;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import cr.ac.ucr.planDeEstudios.datos.CursoDatos;
import cr.ac.ucr.planDeEstudios.dominio.Curso;


@Service
public class CursoNegocios {

	@Autowired
	private CursoDatos  cursoDatos;
	
	@Autowired
	public List<Curso> encontrarCursos() {
		return cursoDatos.encontrarCursos();
	}
	
	
	public Curso guardar(Curso curso)
	{
		if(curso == null) throw new RuntimeException("El curso es requerida.");
		if(curso.getNombre().length() <= 0 ) throw new RuntimeException("El nombre es requerido");
		if(curso.getNombre().equalsIgnoreCase(curso.getRequisito().getNombre()) ) throw new RuntimeException("No puede ser él mismo como requisito");
		
			
		return cursoDatos.guardar(curso);
	}

	public void actualizar(Curso curso, String sigla) 
	{
		if(curso == null) throw new RuntimeException("El curso es requerida.");
		if(curso.getNombre().length() > 200 ) throw new RuntimeException("El nombre no puede tener más de 200 caracteres.");
		if(curso.getNombre().equalsIgnoreCase(curso.getRequisito().getNombre()) ) throw new RuntimeException("No puede ser él mismo como requisito");
			
		cursoDatos.actualizar(curso, sigla);
	}


	public void eliminar(Curso curso, String sigla) {
		if(curso == null) throw new RuntimeException("El curso es requerida.");
		
		
		cursoDatos.eliminar(curso, sigla);
		
	}
	
	
}
