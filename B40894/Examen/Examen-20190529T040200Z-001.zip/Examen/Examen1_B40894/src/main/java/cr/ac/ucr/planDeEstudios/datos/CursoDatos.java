package cr.ac.ucr.planDeEstudios.datos;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Repository;

import cr.ac.ucr.planDeEstudios.dominio.Curso;
import cr.ac.ucr.planDeEstudios.dominio.Requisito;

@Repository
public class CursoDatos {

	private List<Curso> cursosCreados = new ArrayList<Curso>();
	
	@Autowired
	public List<Curso> encontrarCursos() {
		
		
		Curso curso1= new Curso("Programacion", "P", 3, null);
		Requisito requisito = new Requisito("Programacion", "P", 3);
		Curso curso2= new Curso("Lenguajes", "L", 3, requisito);
		
		cursosCreados.add(curso1);
		cursosCreados.add(curso2);
		
		return cursosCreados;
	}

	
	public Curso guardar(Curso curso) {
		
		cursosCreados.add(curso);
		return curso;
	}

	
	public void actualizar(Curso curso, String sigla) {
		for (int contadorDeLugares = 0; contadorDeLugares < cursosCreados.size(); contadorDeLugares++) {
			if (cursosCreados.get(contadorDeLugares).getSiglas().equalsIgnoreCase(sigla)) {
				cursosCreados.set(contadorDeLugares, curso);
			}
		}
		
	}


	public void eliminar(Curso curso, String sigla) {
		for (int contadorDeLugares = 0; contadorDeLugares < cursosCreados.size(); contadorDeLugares++) {
			if (cursosCreados.get(contadorDeLugares).getSiglas().equalsIgnoreCase(sigla)) {
				cursosCreados.remove(contadorDeLugares);
			}
		}
		
	}

}
