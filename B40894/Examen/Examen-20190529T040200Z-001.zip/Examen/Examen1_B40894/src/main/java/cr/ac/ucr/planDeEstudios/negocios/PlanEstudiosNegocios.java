package cr.ac.ucr.planDeEstudios.negocios;

import org.springframework.beans.factory.annotation.Autowired;

import cr.ac.ucr.planDeEstudios.dominio.PlanEstudios;

public class PlanEstudiosNegocios {

	@Autowired
	private PlanEstudios planEstudiosDatos;
	
}
