package cr.ac.ucr.planDeEstudios.controlador;

public class PlanEstudiosControlador {

}
