package cr.ac.ucr.planDeEstudios.dominio;

import java.util.List;

public class Curso {

	private String nombre;
	private String siglas;
	private int creditos;
	private Requisito requisito;
	
	
	
	public Curso(String nombre, String siglas, int creditos, Requisito requisito) {
		super();
		this.nombre = nombre;
		this.siglas = siglas;
		this.creditos = creditos;
		this.requisito = requisito;
	}
	
	
	public Curso() {
		super();
	}


	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getSiglas() {
		return siglas;
	}
	public void setSiglas(String siglas) {
		this.siglas = siglas;
	}
	public int getCreditos() {
		return creditos;
	}
	public void setCreditos(int creditos) {
		this.creditos = creditos;
	}
	public Requisito getRequisito() {
		return requisito;
	}
	public void setRequisito(Requisito requisito) {
		this.requisito = requisito;
	}


 

	
	
	
}
