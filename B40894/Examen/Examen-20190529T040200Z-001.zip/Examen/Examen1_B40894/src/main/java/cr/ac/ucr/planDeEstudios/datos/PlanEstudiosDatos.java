package cr.ac.ucr.planDeEstudios.datos;

public class PlanEstudiosDatos {

}
