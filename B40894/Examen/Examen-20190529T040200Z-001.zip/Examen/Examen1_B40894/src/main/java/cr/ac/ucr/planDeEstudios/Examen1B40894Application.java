package cr.ac.ucr.planDeEstudios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Examen1B40894Application {

	public static void main(String[] args) {
		SpringApplication.run(Examen1B40894Application.class, args);
	}

}
